    <div class="banner before_up" >
        <div>
            <h2>Has tus mejores apuestas y garantiza tu dinero</h2>
            <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Accusamus, saepe.</p>
        </div>
        <a href="#" >Casas de apuestas</a>
    </div>